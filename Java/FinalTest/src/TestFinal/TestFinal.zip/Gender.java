package TestFinal;

public enum Gender {
	Male,Female;
}
